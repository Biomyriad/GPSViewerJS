# Description
An HTML to Javascript DOM converter

# Online Tool
[HTML to DOM Github Page](https://damian96.github.io/html-to-dom/)

# Changelog
[v1.0.0 - First release](https://github.com/Damian96/html-to-dom/releases/tag/v1.0.0)

[v1.1.0 - Second release](https://github.com/Damian96/html-to-dom/releases/tag/v1.1.0)

# License
Licensed under the [MIT license](LICENSE)